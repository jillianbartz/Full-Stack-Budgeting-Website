Deployed website: http://recitation-12-team-04.eastus.cloudapp.azure.com:3000/

![Alt text](../Code/views/resources/images/Deployed_Software_Dev_Final_project_screenshot.png)
![Screenshots](../Code/views/resources/images/Deployed_Software_Dev_Final_Project_Jan_Page.png)