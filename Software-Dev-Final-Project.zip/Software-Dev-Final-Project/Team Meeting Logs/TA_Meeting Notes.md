Meeting #1 with Shipra (17 minutes long):
 
Discussed Lab 10 deliverables:  

    - Completed (1-4) deliverables

    - Need to create overview of directory(partials,pages)

	- Make more progress on ReadME

Decisions made: 

    - Don't use iMessages

    - Switched to Discord 

Follow Up items:

    - Create meeting plan(how often we meet)


Week 2: 11/15/2023: Neeting #2 with Shipra for Lab 11 (15 minutes long):

Discussed progress on Lab 11 test cases

    - discussed UAT requirements 

    - discussed database setup

    - discussed when to create user stories/database so that we are good to go for project after Fall break

Decisions made:

    - Need to clean up the formatting on the UAT document (Shipra wanted the UAT requirements to be formatted in a table so it is clearer/easier to understand)

    - Continue working on the Logout and Register test cases and complete them before 11/16


Follow Up items:

    - Create user stories by end of week

    - Assign roles/divide up tasks for parts of the website to everyone

    - Clean up UAT document

    - Create a plan of when to create database/how to create it before end of week 
    

Week 3: 11/29/2023: Meeting #3 with Shipra for Lab 11 (18 minutes long):

Discussed progress on Lab 11 

    - discussed front-end progress 

    - discussed database progress

    - discussed equal contribution 

Decisions made:

    - Need to imporve at delegating tasks specifically  
    
    - Meet everyday throught the next week and a half

Follow Up items:

    - Have a working demo for our meeting next week with Shipra

    - Continue updating the UAT

    - Finish database  


Week 4: 12/6/2023: Meeting #4 with Shipra  (12 minutes long):

Discussed progress on website

    - Discussed front-end and back-end work along with test cases

    - Ran a demo of the deployed website for Shipra

    - Discussed work on the presentation  and slides for 12/7/2023 

Decisions made:

    - Change some front end work; specifically change positioning of logout button and change the titles of each month to be: {Month} instead of {Month Budget}


Follow Up items:

    - Work on presentation and present it tomorrow (12/7/2023)